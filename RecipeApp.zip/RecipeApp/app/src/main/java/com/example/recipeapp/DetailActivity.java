package com.example.recipeapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private TextView title, ingredients, steps, type;
    private RecipeDBAdaptor recipeDBAdaptor;
    private Long rowId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recipeDBAdaptor = new RecipeDBAdaptor(this);
        try {
            recipeDBAdaptor.open();
        } catch (RecipeDBAdaptor.SQLException e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_detail);
        setTitle(R.string.page_title_recipe);
        findViews();
        rowId = (savedInstanceState == null) ? null :
                (Long) savedInstanceState.getSerializable(RecipeDBAdaptor.KEY_ID);

        if (rowId == null){
            Bundle extras = getIntent().getExtras();
            rowId = extras != null ? extras.getLong(RecipeDBAdaptor.KEY_ID)
                    : null;
        }
        populateData();
    }

    public void findViews() {
        title = (TextView) findViewById(R.id.activity_detail_title);
        ingredients = (TextView) findViewById(R.id.activity_detail_ingredients);
        steps = (TextView) findViewById(R.id.activity_detail_steps);
        type = (TextView) findViewById(R.id.activity_detail_type);
    }

    public void populateData() {
        if (rowId != null) {

            Cursor cursor = null;
            try {
                cursor = recipeDBAdaptor.fetchRecipe(rowId);
            } catch (RecipeDBAdaptor.SQLException e) {
                e.printStackTrace();
            }
            startManagingCursor(cursor);

            title.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_TITLE)));

            ingredients.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_INGREDIENTS)));

            steps.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_STEPS)));

            type.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_TYPE)));
        }
    }
}
