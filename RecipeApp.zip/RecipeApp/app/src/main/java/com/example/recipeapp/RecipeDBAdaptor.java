package com.example.recipeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class RecipeDBAdaptor {
    private static final String DATABASE_NAME = "recipedb";
    private static final String DATABASE_TABLE = "recipe";
    private static final int DATABASE_VERSION = 1;
    public static final String KEY_ID = "_id";
    public static final String KEY_TITLE = "title";
    public static final String KEY_INGREDIENTS = "ingredients";
    public static final String KEY_STEPS = "steps";
    public static final String KEY_TYPE = "type";
    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + DATABASE_TABLE + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_TITLE + " TEXT NOT NULL, " + KEY_INGREDIENTS + " TEXT NOT NULL, " + KEY_STEPS + " TEXT NOT NULL, " + KEY_TYPE + " TEXT NOT NULL)";
    private static String DROP_TABLE = "DROP TABLE IF EXISTS " + DATABASE_TABLE;
    private final Context mContext;
    private DBHelper mDBHelper;
    private SQLiteDatabase mSQLiteDatabase;
    public RecipeDBAdaptor(Context context) {
        this.mContext = context;
    }
    private static class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context) {

            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {

            sqLiteDatabase.execSQL(CREATE_TABLE);

            ContentValues contentValues = new ContentValues();
            contentValues.put(KEY_TITLE, "Caprese Appetizer");
            contentValues.put(KEY_INGREDIENTS, "- 20 grape tomatoes\n- 10 ounces mozzarella cheese, cubed\n- 2 tablespoons extra virgin olive oil\n- 2 tablespoons fresh basil leaves, chopped\n- 1 pinch salt\n- 1 pinch ground black pepper\n- 20 toothpicks");
            contentValues.put(KEY_STEPS, "1. Toss tomatoes, mozzarella cheese, olive oil, basil, salt, and pepper together in a bowl until well coated\n2. Skewer one tomato and one piece of mozzarella cheese on each toothpick");
            contentValues.put(KEY_TYPE, "Appetizer");
            sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);

            contentValues.put(KEY_TITLE, "Bell Pepper Nachos");
            contentValues.put(KEY_INGREDIENTS, "- 4 bell peppers\n- 2 teaspoons seasoning (try a mixture-chili powder, garlic powder, ground cumin, pepper)\n- 2 cups cooked meat (chopped or shredded), beans or tofu\n- 1 cup reduced fat shredded cheese");
            contentValues.put(KEY_STEPS, "1. Preheat oven to 350 degrees\n2. Wash bell peppers, remove seeds and cut into bite-sized pieces. Arrange pieces close together in a single layer on a large foil-lined baking sheet\n3. In a medium bowl, combine salsa, seasonings and meat, beans or tofu.  Spoon the mixture evenly over pepper pieces then top with cheese.\n4. Bake for 15 minutes, or until peppers are heated through and cheese is melted. Serve warm\n- Refrigerate leftovers within 2 hours.");
            contentValues.put(KEY_TYPE, "Main Course");
            sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);

            contentValues.put(KEY_TITLE, "Creamy Potato Leek Soup");
            contentValues.put(KEY_INGREDIENTS, "- 3 leeks (about 3 cups diced)\n- 3 potatoes (about 3 cups diced)\n- 2 Tablespoons butter or margarine\n- 4 1⁄2 cups chicken broth\n- 1⁄4 cup 1% milk\n- 2 garlic cloves, minced or 1/2 teaspoon garlic powder\n- 1⁄2 teaspoon black pepper");
            contentValues.put(KEY_STEPS, "1. Remove root and green tops from leeks.  Slice in half lengthwise and rinse well under running water.  Slice crosswise into ¼ inch slices. \n2. Scrub potatoes well; cut into small cubes.\n3. Melt butter or margarine in a 2-quart saucepan over medium heat.\n4. Add garlic and chopped leeks. Cook until softened.\n5. Add potatoes and enough broth to cover.  Cover pan and simmer until potatoes are soft.  Mash with a potato masher or fork until potatoes are fairly smooth\n6. Add remaining broth, milk and pepper.  Simmer for about 5 minutes\n7. Refrigerate leftovers within 2 hours.");
            contentValues.put(KEY_TYPE, "Soup");
            sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);

            contentValues.put(KEY_TITLE, "Green Salad with Peas");
            contentValues.put(KEY_INGREDIENTS, "- 1 cup peas\n- 1⁄2 cup chopped cucumber\n- 1⁄2 cup low-fat salad dressing\n- 1⁄2 cup low-fat feta cheese");
            contentValues.put(KEY_STEPS, "1. Thaw and drain frozen peas or drain canned peas\n2. Combine peas, salad greens and cucumber in a large serving bowl.\n3. Add dressing just before serving. Toss to mix well. Sprinkle with feta cheese.\n4. Refrigerate leftovers within 2 hours.");
            contentValues.put(KEY_TYPE, "Side Dish");
            sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);

            contentValues.put(KEY_TITLE, "Strawberry Cake");
            contentValues.put(KEY_INGREDIENTS, "- Strawberry\n- 6 cups salad greens\n- Milk\n- Sugar\n- Eggs");
            contentValues.put(KEY_STEPS, "1. Mix Eggs with Milk\n2. Mix Flour with Strawberry and Sugar\n3. Mix all together\n4. Bake for 40min");
            contentValues.put(KEY_TYPE, "Dessert");
            sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
            sqLiteDatabase.execSQL(DROP_TABLE);
            onCreate(sqLiteDatabase);

        }
    }

    public RecipeDBAdaptor open() throws SQLException {
        mDBHelper = new DBHelper(mContext);
        mSQLiteDatabase = mDBHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        mDBHelper.close();
    }

    public long createRecipe(String title, String ingredients, String steps, String type) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_TITLE, title);
        contentValues.put(KEY_INGREDIENTS, ingredients);
        contentValues.put(KEY_STEPS, steps);
        contentValues.put(KEY_TYPE, type);
        return mSQLiteDatabase.insert(DATABASE_TABLE, null, contentValues);
    }

    public boolean deleteRecipe(long keyID) {
        return mSQLiteDatabase.delete(DATABASE_TABLE, KEY_ID + "=" + keyID, null) > 0;
    }

    public Cursor fetchAllRecipes() {
        return mSQLiteDatabase.query(DATABASE_TABLE, new String[]{KEY_ID, KEY_TITLE,
                KEY_INGREDIENTS, KEY_STEPS, KEY_TYPE}, null, null, null, null, null);
    }

    public Cursor fetchLike(String filter) {
        return mSQLiteDatabase.query(true, DATABASE_TABLE, new String[]{KEY_ID,
                        KEY_TITLE, KEY_INGREDIENTS, KEY_STEPS, KEY_TYPE}, KEY_TYPE + " LIKE ?",
                new String[]{"%" + filter + "%"}, null, null, null,
                null, null);
    }

    public Cursor fetchRecipe(long keyID) throws SQLException {

        Cursor mCursor = mSQLiteDatabase.query(true, DATABASE_TABLE, new String[]{KEY_ID,
                        KEY_TITLE, KEY_INGREDIENTS, KEY_STEPS, KEY_TYPE}, KEY_ID + "=" + keyID, null,
                null, null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public boolean updateRecipe(long keyID, String title, String ingredients, String steps, String type) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_TITLE, title);
        contentValues.put(KEY_INGREDIENTS, ingredients);
        contentValues.put(KEY_STEPS, steps);
        contentValues.put(KEY_TYPE, type);


        return mSQLiteDatabase.update(DATABASE_TABLE, contentValues, KEY_ID + "=" + keyID, null) > 0;
    }

    public class SQLException extends Exception {
    }
}
