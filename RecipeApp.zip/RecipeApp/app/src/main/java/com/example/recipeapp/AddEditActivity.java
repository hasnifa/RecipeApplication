package com.example.recipeapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.List;

public class AddEditActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText title, ingredients, steps;
    private RecipeDBAdaptor recipeDBAdaptor;
    private List<RecipeType> recipeTypes;
    private Spinner type;
    private Button button;
    private Long rowId;
    String dbType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recipeDBAdaptor = new RecipeDBAdaptor(this);

        try {
            recipeDBAdaptor.open();
        } catch (RecipeDBAdaptor.SQLException e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_add_edit);
        setTitle(R.string.page_title_editor);
        findViews();
        rowId = (savedInstanceState == null) ? null :
                (Long) savedInstanceState.getSerializable(RecipeDBAdaptor.KEY_ID);
        if (rowId == null) {
            Bundle extras = getIntent().getExtras();
            rowId = extras != null ? extras.getLong(RecipeDBAdaptor.KEY_ID)
                    : null;
        }
        dbType = "";
        populateData();
        populateSpinnerData();
    }

    public void findViews() {
        title = (EditText) findViewById(R.id.activity_add_edit_title);
        ingredients = (EditText) findViewById(R.id.activity_add_edit_ingredients);
        steps = (EditText) findViewById(R.id.activity_add_edit_steps);
        type = (Spinner) findViewById(R.id.spinner_activity_add_edit_layout);
        button = (Button) findViewById(R.id.button_save_activity_add_edit_layout);
        button.setOnClickListener(this);

    }

    public void populateData() {
        if (rowId != null) {
            Cursor cursor = null;
            try {
                cursor = recipeDBAdaptor.fetchRecipe(rowId);
            } catch (RecipeDBAdaptor.SQLException e) {
                e.printStackTrace();
            }
            startManagingCursor(cursor);
            title.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_TITLE)));
            ingredients.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_INGREDIENTS)));
            steps.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_STEPS)));
            dbType = cursor.getString(
                    cursor.getColumnIndexOrThrow(RecipeDBAdaptor.KEY_TYPE));
        }

    }

    public void populateSpinnerData() {
        recipeTypes = null;
        try {
            XMLPullParserHandler parser = new XMLPullParserHandler();
            recipeTypes = parser.parse(getAssets().open("recipetypes.xml"));
            ArrayAdapter<RecipeType> adapter =
                    new ArrayAdapter<RecipeType>(this, R.layout.recipetype_item, recipeTypes);
            type.setAdapter(adapter);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!dbType.equals(null) || !"".equals(dbType)) {
            int viewPosition;
            switch (dbType) {
                case "Appetizer":
                    viewPosition = 0;
                    break;
                case "Main Course":
                    viewPosition = 1;
                    break;
                case "Soup":
                    viewPosition = 2;
                    break;
                case "Side Dish":
                    viewPosition = 3;
                    break;
                case "Dessert":
                    viewPosition = 4;
                    break;

                default:
                    viewPosition = 0;
            }

            type.setSelection(viewPosition);
        }

    }


    @Override
    public void onClick(View view) {
        setResult(RESULT_OK);
        finish();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(RecipeDBAdaptor.KEY_ID, rowId);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateData();
    }

    private void saveState() {
        String titleString = title.getText().toString();
        String ingredientString = ingredients.getText().toString();
        String stepsString = steps.getText().toString();
        String typeString = type.getSelectedItem().toString();
        if (titleString.equals(null) || "".equals(title) || ingredientString.equals(null) || "".equals(ingredientString) || stepsString.equals(null) || "".equals(stepsString) || typeString.equals(null) || "".equals(typeString)) {
            Toast.makeText(this, R.string.toast_notification, Toast.LENGTH_SHORT).show();
        } else {
            if (rowId == null) {
                long id = recipeDBAdaptor.createRecipe(titleString, ingredientString, stepsString, typeString);
                if (id > 0) {
                    rowId = id;
                }
            } else {
                recipeDBAdaptor.updateRecipe(rowId, titleString, ingredientString, stepsString, typeString);
            }
        }
    }

}
