package com.example.recipeapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener {
    private Spinner spinner;
    private List<RecipeType> recipeTypes;
    private ListView listView;
    private Button buttonFilter, buttonClear;
    private RecipeDBAdaptor recipeDBAdaptor;
    private ListAdapter listAdapter;

    private static final int ACTIVITY_CREATE = 0;
    private static final int ACTIVITY_EDIT = 1;
    private static final int CREATE_ID = Menu.FIRST;
    private static final int DELETE_ID = Menu.FIRST + 1;
    private static final int EDIT_ID = Menu.FIRST + 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
        populateSpinnerData();
        populateListData();
    }

    public void findViews() {
        spinner = (Spinner) findViewById(R.id.spinner_activity_recipe_layout);
        buttonFilter = (Button) findViewById(R.id.button_filter_activity_recipe_layout);
        buttonFilter.setOnClickListener(this);

        buttonClear = (Button) findViewById(R.id.button_clear_activity_recipe_layout);
        buttonClear.setOnClickListener(this);

        listView = (ListView) findViewById(R.id.listview_activity_recipe_layout);
        listView.setOnItemClickListener(this);
        registerForContextMenu(listView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, CREATE_ID, 0, R.string.add_recipe);
        menu.add(0, EDIT_ID, 0, R.string.edit_recipe);
        menu.add(0, DELETE_ID, 0, R.string.delete_recipe);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case DELETE_ID:
                recipeDBAdaptor.deleteRecipe(info.id);
                populateListData();
                return true;
            case CREATE_ID:
                createRecipe();
                return true;
            case EDIT_ID:
                Intent i = new Intent(this, AddEditActivity.class);
                i.putExtra(RecipeDBAdaptor.KEY_ID, info.id);
                startActivityForResult(i, ACTIVITY_EDIT);
                return true;
        }
        return super.onContextItemSelected(item);
    }

    public void populateSpinnerData() {
        recipeTypes = null;

        try {
            XMLPullParserHandler parser = new XMLPullParserHandler();
            recipeTypes = parser.parse(getAssets().open("recipetypes.xml"));
            ArrayAdapter<RecipeType> adapter =
                    new ArrayAdapter<RecipeType>(this, R.layout.recipetype_item, recipeTypes);
            spinner.setAdapter(adapter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void populateListData() {
        recipeDBAdaptor = new RecipeDBAdaptor(this);
        try {
            recipeDBAdaptor.open();
        } catch (RecipeDBAdaptor.SQLException e) {
            e.printStackTrace();
        }

        Cursor cursor = recipeDBAdaptor.fetchAllRecipes();

        listAdapter = new SimpleCursorAdapter(this, R.layout.listview_item, cursor,
                new String[]{recipeDBAdaptor.KEY_TITLE}, new int[]{
                R.id.listviewlayout_item});
        listView.setAdapter(listAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        menu.add(0, CREATE_ID, 0, R.string.add_recipe);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case CREATE_ID:

                createRecipe();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void createRecipe() {
        Intent i = new Intent(this, AddEditActivity.class);
        startActivityForResult(i, ACTIVITY_CREATE);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(RecipeDBAdaptor.KEY_ID, id);
        startActivityForResult(intent, ACTIVITY_EDIT);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_filter_activity_recipe_layout:
                String filter = spinner.getSelectedItem().toString();
                recipeDBAdaptor = new RecipeDBAdaptor(this);
                try {
                    recipeDBAdaptor.open();
                } catch (RecipeDBAdaptor.SQLException e) {
                    e.printStackTrace();
                }
                Cursor cursor = recipeDBAdaptor.fetchLike(filter);
                listAdapter = new SimpleCursorAdapter(this, R.layout.listview_item, cursor,
                        new String[]{recipeDBAdaptor.KEY_TITLE}, new int[]{
                        R.id.listviewlayout_item});
                listView.setAdapter(listAdapter);
                break;
            case R.id.button_clear_activity_recipe_layout:
                populateListData();
                break;
            default:
                break;
        }
    }
}